
# PãoBot

Meu primeiro projeto em python, um bot para [Discord](https://discord.com/) feito inicialmente com a biblioteca [Discord.py](https://github.com/Rapptz/discord.py), que foi descontinuada, sendo agora transferido para Disnake.

O prefixo do bot é `p.`.

